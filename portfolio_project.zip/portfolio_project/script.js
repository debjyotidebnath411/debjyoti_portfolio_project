// Handle Recommendation Submission
document.getElementById("recommendation-form").addEventListener("submit", function(event) {
  event.preventDefault();

  let input = document.getElementById("recommendation-input");
  let newRec = input.value.trim();

  if(newRec !== "") {
    // Add to list
    let li = document.createElement("li");
    li.textContent = newRec;
    document.getElementById("recommendation-list").appendChild(li);

    // Show confirmation popup
    alert("Recommendation submitted successfully!");

    // Clear input
    input.value = "";
  }
});
